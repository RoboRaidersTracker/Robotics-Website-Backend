const {
  DynamoDB,
  PutItemCommand,
  CreateTableCommand,
  ListTablesCommand,
  QueryCommand,
  BatchWriteItemCommand,
  ScanCommand
} = require("@aws-sdk/client-dynamodb");
const uuid_v1 = require("uuid").v1;

let ddb;
try {
  ddb = new DynamoDB(require("./local.json"))
} catch (error) {
  ddb = new DynamoDB({ region: "us-east-1" });
}

const tables = {
  sessions: "team75_tracking_sessions",
  students: "team75_tracking_students",
  initiatives: "team75_tracking_initiatives",
  departments: "team75_tracking_departments"
}

init();

async function init() {
  ddb.send(new ListTablesCommand({})).then(async res => {
    // Create tables if they don't exist
    const schemas = require("./data_structure.json");
    const currTables = res.TableNames;
    for (const table of Object.entries(tables)) {
      if (!currTables.includes(table[1])) {
        await ddb.send(
          new CreateTableCommand(schemas[table[0]])
        );
      }
    }

    // Push mock data
    initSampleData();
  })
}

async function initSampleData() {
  try {
    await addUser(
      "114409764148443206366",
      "Eshaan Debnath",
      "eshaandebnath@gmail.com",
      "https://lh3.googleusercontent.com/a/AAcHTtfsmybpx59Z8dwUWN1saEu0Cm8Pwsl_h_PKns9e5w=s100",
      "Programming",
      "mentor"
    )
  } catch { }
}

async function addSession(session_token, timestamp, user_id, department_name, tags) {
  if (typeof timestamp === "number") {
    timestamp = timestamp.toString();
  }
  if (typeof tags === "string") {
    tags = [{ "S": tags }]
  } else if (Array.isArray(tags)) {
    tags = tags.map(el => { return { "S": el } })
  }

  let session_data = {
    "TableName": "team75_tracking_sessions",
    "Item": {
      "session_token": {
        "S": session_token
      },
      "timestamp": {
        "N": timestamp
      },
      "user_id": {
        "S": user_id
      },
      "department_name": {
        "S": department_name
      },
      "tags": {
        "L": tags
      }
    }
  }

  ddb.send(new PutItemCommand(session_data));
}

async function findSession(session_token) {
  let query = {
    "TableName": "team75_tracking_sessions",
    "ScanIndexForward": true,
    "ConsistentRead": true,
    "KeyConditionExpression": "#232f0 = :232f0",
    "ExpressionAttributeValues": {
      ":232f0": {
        "S": session_token
      }
    },
    "ExpressionAttributeNames": {
      "#232f0": "session_token"
    }
  }

  let res = await ddb.send(new QueryCommand(query));

  return res.Items[0];
}

async function cleanSessions(expireMins, currTime) {
  let query = {
    "TableName": "team75_tracking_sessions",
    "ConsistentRead": true,
    "ProjectionExpression": "#0ca70,#0ca71",
    "ExpressionAttributeNames": {
      "#0ca70": "timestamp",
      "#0ca71": "session_token"
    }
  }

  let res = await ddb.send(new ScanCommand(query)), delItems = [];

  res.Items.forEach(session => {
    if (parseInt(session.timestamp.N) + expireMins < currTime) {
      delItems.push({
        DeleteRequest: {
          Key: {
            "session_token": session.session_token,
            "timestamp": session.timestamp
          }
        }
      })
    }
  })

  for (let i = 0; i < Math.ceil(delItems.length / 25); i++) {
    let slice = delItems.slice(i * 25, i * 25 + 25);
    query = { RequestItems: {} };
    query["RequestItems"][tables["sessions"]] = slice;
    await ddb.send(new BatchWriteItemCommand(query));
  }
}

async function addUser(g_id, g_name, g_email, g_photo, department_name, tags) {
  if (typeof g_id === "number") {
    g_id = g_id.toString();
  }

  if (await loginUser(g_id) != undefined) {
    return;
  }

  if (typeof tags === "string") {
    tags = [{ "S": tags }]
  } else if (Array.isArray(tags)) {
    tags = tags.map(el => { return { "S": el } })
  }
  let userID = uuid_v1();

  let student_data = {
    "TableName": "team75_tracking_students",
    "Item": {
      "user_id": {
        "S": userID
      },
      "email": {
        "S": g_email
      },
      "google_id": {
        "S": g_id
      },
      "name": {
        "S": g_name
      },
      "profile_picture": {
        "S": g_photo
      },
      "department_name": {
        "S": department_name
      },
      "tags": {
        "L": tags
      },
      "initiative_hours": {
        "N": "0"
      },
      "initiative_data": {
        "L": [
          {
            "M": {}
          }
        ]
      },
      "attendance": {
        "L": [
          {
            "M": {}
          }
        ]
      }
    }
  }

  ddb.send(new PutItemCommand(student_data));
}

async function loginUser(g_id) {
  let query = {
    "TableName": "team75_tracking_students",
    "ScanIndexForward": true,
    "IndexName": "SecureLogin",
    "KeyConditionExpression": "#35f20 = :35f20",
    "ExpressionAttributeValues": {
      ":35f20": {
        "S": g_id
      }
    },
    "ExpressionAttributeNames": {
      "#35f20": "google_id"
    }
  }

  let res = await ddb.send(new QueryCommand(query));

  return res.Items[0];
}

module.exports = {
  init,
  addSession,
  findSession,
  cleanSessions,
  addUser,
  loginUser
}
