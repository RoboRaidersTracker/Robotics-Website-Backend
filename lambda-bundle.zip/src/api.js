const { readFileSync } = require("fs");
const { init, addSession, findSession, cleanSessions, addUser, loginUser } = require("./dynamo_wrapper");
const { setOrigin, getTokens, getClientID } = require("./google_oauth");
const newSession = () => require("randomstring").generate({
  length: 20,
  charset: "alphanumeric"
});

// Home page
const pageCode = readFileSync("./src/page.html", "utf-8");

// Session management
let user_cache = [];
const expireMins = 1;
const databaseCleanRateMins = 60*24*3;

let lastDatabaseClean = timestamp();

async function forceInit() {
  init();
}

function timestamp() {
  return Math.floor((new Date() - new Date("Jan 1 2020 00:00:00 GMT")) / 1000 / 60);
}

async function cleanCacheAndDatabase() {
  for (let i = user_cache.length - 1; i >= 0; i--) {
    if (user_cache[i].timestamp + expireMins <= timestamp()) {
      user_cache = user_cache.slice(i + 1);
      return;
    }
  }

  if (lastDatabaseClean + databaseCleanRateMins <= timestamp()) {
    cleanSessions(expireMins, timestamp());
  }
}

/* ----- API Functions ----- */
async function homepage() {
  return {
    "statusCode": 200,
    "headers": { "Content-Type": "text/html" },
    "body": pageCode
  }
};

async function checkLogin(cookies) {
  if (cookies["session-token"] == undefined) {
    return {
      "statusCode": 404
    }
  }

  // Check local cache
  let res = user_cache.find(el => el["session_token"] == cookies["session-token"]
    && el["issued"] + expireMins > timestamp());

  if (res != undefined) {
    return {
      "statusCode": 200,
      "headers": {
        "Content-Type": "application/json",
      },
      "body": { "message": "Success!" }
    }
  }

  // Check database
  let session = await findSession(cookies["session-token"])

  if (session != undefined) {
    let session_timestamp = parseInt(session.timestamp.N);
    if (session_timestamp + expireMins > timestamp()) {
      // Update local cache
      user_cache.push({
        session_token: session.session_token.S,
        timestamp: session_timestamp,
        user_id: session.user_id.S,
        department: session.department_name.S,
        tags: session.tags.L.map(el => el.S)
      });

      return {
        "statusCode": 200,
        "headers": {
          "Content-Type": "application/json",
        },
        "body": { "message": "Success!" }
      }
    }
  }

  // If both fail, throw error
  return {
    "statusCode": 404
  }
}

async function loginClient(origin, body) {
  try {
    setOrigin(origin);
    const { code } = body;
    const { tokens, oauth2Client } = await getTokens(code);
    const g_data = await getClientID(tokens, oauth2Client);

    let session_token = newSession(), user = await loginUser(g_data.id), currTime = timestamp();

    // Save to local cache
    user_cache.push({
      session_token: session_token,
      timestamp: currTime,
      user_id: user.user_id.S,
      department: user.department_name.S,
      tags: user.tags.L.map(el => el.S)
    });

    // Save to database
    addSession(session_token, currTime, user.user_id.S, user.department_name.S, user.tags.L.map(el => el.S));

    // Add user
    // addUser(g_data.id, g_data.name, g_data.email, g_data.photo, "mentor");

    let expireTime = new Date();
    expireTime.setSeconds(expireTime.getSeconds() + Math.floor(expireMins * 60));
    expireTime = expireTime.toUTCString();

    return {
      "statusCode": 200,
      "headers": {
        "Content-Type": "application/json",
        "Set-Cookie": `session-token=${session_token}; Expires=${expireTime}; HttpOnly;`
      },
      "body": { "message": "Success!" }
    }
  } catch (error) {
    console.log(error)
    return {
      "statusCode": 401,
      "headers": { "Content-Type": "application/json" },
      "body": { "message": "Unauthorized.", "details": error }
    }
  }
}

module.exports = {
  forceInit,
  cleanCacheAndDatabase,
  homepage,
  checkLogin,
  loginClient
}
